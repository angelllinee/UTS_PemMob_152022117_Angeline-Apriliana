import 'package:flutter/material.dart';
import 'package:login_page/screen/bmi.dart';
import 'package:login_page/screen/calculator.dart';
import 'package:login_page/screen/temp_convert.dart'; // Import untuk Temp Convert screen
import 'package:login_page/screen/discount_convert.dart'; // Import untuk Discount Convert screen

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Linn\'s Dashboard',
          style: TextStyle(
            fontFamily: 'Pop',
            fontSize: 22,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.pink,
        centerTitle: true,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Menambahkan gambar di atas teks
          Image.asset(
            'assets/images/dashboard.png', // Gambar yang ingin ditampilkan
            width: 250, // Ukuran lebar gambar
            height: 150, // Ukuran tinggi gambar
            fit: BoxFit.cover, // Gambar akan disesuaikan dengan ukuran yang diberikan
          ),
          const SizedBox(height: 40),

          const Center(
            child: Text(
              'Halo? Welcome! -`♡´-',
              style: TextStyle(
                fontFamily: 'Pop',
                fontSize: 20,
                color: Colors.black,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 40),

          // Tombol untuk menuju ke halaman Calculator
          SizedBox(
            width: 250,
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CalculatorScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
                padding: const EdgeInsets.symmetric(vertical: 15.0),
              ),
              child: const Text(
                'Calculator ⋆. 𐙚˚',
                style: TextStyle(
                  fontFamily: 'Pop',
                  fontSize: 18,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Tombol untuk menuju ke halaman BMI
          SizedBox(
            width: 250,
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => BMIScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
                padding: const EdgeInsets.symmetric(vertical: 15.0),
              ),
              child: const Text(
                'BMI ⋆. 𐙚˚',
                style: TextStyle(
                  fontFamily: 'Pop',
                  fontSize: 18,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Tombol untuk menuju ke halaman Temperature Converter
          SizedBox(
            width: 250,
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TemperatureConverter()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
                padding: const EdgeInsets.symmetric(vertical: 15.0),
              ),
              child: const Text(
                'Temperature ⋆. 𐙚˚',
                style: TextStyle(
                  fontFamily: 'Pop',
                  fontSize: 18,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Tombol untuk menuju ke halaman Discount Converter
          SizedBox(
            width: 250,
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DiscountConvert()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
                padding: const EdgeInsets.symmetric(vertical: 15.0),
              ),
              child: const Text(
                'Discount ⋆. 𐙚˚',
                style: TextStyle(
                  fontFamily: 'Pop',
                  fontSize: 18,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
