import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Import intl package untuk format mata uang

class DiscountConvert extends StatefulWidget {
  @override
  _DiscountConvertState createState() => _DiscountConvertState();
}

class _DiscountConvertState extends State<DiscountConvert> {
  final TextEditingController originalPriceController = TextEditingController();
  final TextEditingController discountController = TextEditingController();

  String finalPrice = "";
  String discountAmount = "";

  // Fungsi untuk format harga dalam Rupiah
  String formatRupiah(double value) {
    final formatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 2);
    return formatter.format(value);
  }

  void calculateDiscount() {
    double originalPrice = double.tryParse(originalPriceController.text) ?? 0;
    double discount = double.tryParse(discountController.text) ?? 0;

    if (originalPrice > 0 && discount > 0) {
      // Menghitung harga diskon dan harga final
      double discountOff = originalPrice * (discount / 100);
      double finalPriceAfterDiscount = originalPrice - discountOff;

      setState(() {
        discountAmount = "Discount: ${formatRupiah(discountOff)}";
        finalPrice = "Final Price: ${formatRupiah(finalPriceAfterDiscount)}";
      });
    } else {
      // Menampilkan hasil jika input tidak valid
      setState(() {
        discountAmount = "";
        finalPrice = "Please enter valid values.";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Discount Calculator',
          style: TextStyle(
            fontFamily: 'Pop',
            color: Colors.white,
            fontSize: 24, // Menyesuaikan ukuran font
          ),
        ),
        backgroundColor: Colors.pink,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white), // Tombol back berwarna putih
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Input untuk harga asli dengan border terpisah
            TextField(
              controller: originalPriceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Original Price',
                hintText: 'Enter original price',
                labelStyle: TextStyle(fontFamily: 'Pop'), // Menambahkan font Pop pada label
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 12.0), // Memisahkan border
              ),
              style: const TextStyle(fontFamily: 'Pop', color: Colors.black), // Menggunakan font Pop pada teks yang diketik
            ),
            const SizedBox(height: 20),

            // Input untuk persentase diskon dengan border terpisah
            TextField(
              controller: discountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Discount (%)',
                hintText: 'Enter discount percentage',
                labelStyle: TextStyle(fontFamily: 'Pop'), // Menambahkan font Pop pada label
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 12.0), // Memisahkan border
              ),
              style: const TextStyle(fontFamily: 'Pop', color: Colors.black), // Menggunakan font Pop pada teks yang diketik
            ),
            const SizedBox(height: 20),

            // Tombol untuk menghitung harga diskon
            ElevatedButton(
              onPressed: calculateDiscount,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                padding: const EdgeInsets.symmetric(vertical: 15.0),
              ),
              child: const Text(
                'Calculate Discount',
                style: TextStyle(fontSize: 18, fontFamily: 'Pop', color: Colors.white), // Font Pop dan teks putih
              ),
            ),
            const SizedBox(height: 30),

            // Menampilkan hasil perhitungan
            Text(
              discountAmount,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.green,
                fontFamily: 'Pop',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            Text(
              finalPrice,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.red,
                fontFamily: 'Pop',
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
