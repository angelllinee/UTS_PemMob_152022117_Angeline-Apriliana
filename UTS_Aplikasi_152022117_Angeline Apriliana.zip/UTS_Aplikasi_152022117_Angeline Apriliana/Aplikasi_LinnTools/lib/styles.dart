import 'package:flutter/material.dart';

class AppColors {
  static const white = Color(0XFFFFFFFF);
  static const pink = Color(0XFFF50057);
  static const black = Color(0XFF000000);
  static const darkBlue = Color(0XFF00008B);
  static const gray = Color(0XFFE8EBEA);
}

class TextStyles {
  static TextStyle title = const TextStyle(
    fontFamily: 'Pop',
    fontWeight: FontWeight.bold,
    fontSize: 20.0,
    color: AppColors.white,
  );

  static TextStyle body = const TextStyle(
    fontFamily: 'Pop',
    fontWeight: FontWeight.bold,
    fontSize: 14.0,
    color: AppColors.pink,
  );
}