import 'package:flutter/material.dart';

class BMIScreen extends StatefulWidget {
  @override
  _BMIScreenState createState() => _BMIScreenState();
}

class _BMIScreenState extends State<BMIScreen> {
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  String _result = '';
  String _bmiCategory = '';

  // Fungsi untuk menghitung BMI
  void _calculateBMI() {
    final double? weight = double.tryParse(_weightController.text);
    final double? heightCm = double.tryParse(_heightController.text);

    if (weight != null && heightCm != null && weight > 0 && heightCm > 0) {
      final double height = heightCm / 100;
      final double bmi = weight / (height * height);

      setState(() {
        _result = bmi.toStringAsFixed(2);
        if (bmi < 18.5) {
          _bmiCategory = 'Underweight';
        } else if (bmi >= 18.5 && bmi < 24.9) {
          _bmiCategory = 'Normal weight';
        } else if (bmi >= 25 && bmi < 29.9) {
          _bmiCategory = 'Overweight';
        } else {
          _bmiCategory = 'Obesity';
        }
      });
    } else {
      setState(() {
        _result = 'Invalid input';
        _bmiCategory = '';
      });
    }
  }

  // Fungsi untuk menentukan warna berdasarkan kategori BMI
  Color _getCategoryColor() {
    if (_bmiCategory == 'Underweight') {
      return Colors.red;
    } else if (_bmiCategory == 'Normal weight') {
      return Colors.green;
    } else if (_bmiCategory == 'Overweight') {
      return Colors.orange;
    } else if (_bmiCategory == 'Obesity') {
      return Colors.red;
    }
    return Colors.black; // Default color if something goes wrong
  }

  // Fungsi untuk menentukan warna berdasarkan hasil BMI
  Color _getResultColor() {
    if (_result.isNotEmpty) {
      final double bmi = double.tryParse(_result) ?? 0;
      if (bmi < 18.5) {
        return Colors.red;
      } else if (bmi >= 18.5 && bmi < 24.9) {
        return Colors.green;
      } else if (bmi >= 25 && bmi < 29.9) {
        return Colors.orange;
      } else if (bmi >= 30) {
        return Colors.red;
      }
    }
    return Colors.black; // Default color if something goes wrong
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Ubah latar belakang menjadi putih
      appBar: AppBar(
        backgroundColor: Colors.pink,
        title: const Text(
          'BMI',
          style: TextStyle(fontFamily: 'Pop', color: Colors.white, fontSize: 24),
        ),
        centerTitle: true,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.white), // Tombol back berwarna putih
        automaticallyImplyLeading: true, // Ensure the back button is shown
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 40),
            TextField(
              controller: _weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Weight (kg)',
                labelStyle: const TextStyle(fontFamily: 'Pop', color: Colors.pink),  // Perbaikan font di label
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              style: const TextStyle(fontFamily: 'Pop', color: Colors.black), // Menggunakan font Pop pada input
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _heightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Height (cm)',
                labelStyle: const TextStyle(fontFamily: 'Pop', color: Colors.pink),  // Perbaikan font di label
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              style: const TextStyle(fontFamily: 'Pop', color: Colors.black), // Menggunakan font Pop pada input
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: _calculateBMI,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text(
                'Calculate BMI',
                style: TextStyle(fontFamily: 'Pop', fontSize: 18, color: Colors.white),  // Perbaikan font di button
              ),
            ),
            const SizedBox(height: 40),
            if (_result.isNotEmpty) ...[
              // Menambahkan tulisan BMI di atas border hasilnya
              Text(
                'BMI:',
                style: TextStyle(
                  fontFamily: 'Pop',
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: _getResultColor(), // Warna teks mengikuti kategori BMI
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              // Menambahkan border pada hasil BMI
              Container(
                padding: const EdgeInsets.all(12.0),
                decoration: BoxDecoration(
                  color: _getResultColor().withOpacity(0.1), // Menyesuaikan warna dengan kategori BMI
                  border: Border.all(color: _getResultColor(), width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _result,
                  style: TextStyle(
                    fontFamily: 'Pop',
                    fontSize: 26,
                    color: _getResultColor(),
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Category:',
                style: const TextStyle(fontFamily: 'Pop', fontSize: 26, color: Colors.pink), // Font untuk kategori
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(12.0),
                decoration: BoxDecoration(
                  color: _getCategoryColor().withOpacity(0.1), // Set opacity untuk background color
                  border: Border.all(color: _getCategoryColor(), width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _bmiCategory,
                  style: TextStyle(
                    fontFamily: 'Pop',
                    fontSize: 24,
                    color: _getCategoryColor(),
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
