import 'package:flutter/material.dart';
import 'package:login_page/styles.dart';
import 'package:login_page/widget/custom_textfield.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final emailController = TextEditingController();
  final usernameController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool isObscure = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'Sign Up',
          style: TextStyles.title,
        ),
        centerTitle: true,
        backgroundColor: AppColors.pink,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 10.0),
          child: Padding(
            padding: const EdgeInsets.all(0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SizedBox(
                    width: 175,
                    height: 175,
                    child: Image.asset('assets/images/signup.png'),
                  ),
                  const SizedBox(height: 18.0),
                  Center(
                    child: Text(
                      '✿ Create Your Account! ✿',
                      style: TextStyles.title.copyWith(
                        fontSize: 22.0,
                        color: AppColors.pink,
                      ),
                    ),
                  ),
                  const SizedBox(height: 18.0),
                  CustomTextfield(
                    controller: emailController,
                    textInputType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    hint: 'Email',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Email tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 18.0),
                  CustomTextfield(
                    controller: usernameController,
                    textInputType: TextInputType.text,
                    textInputAction: TextInputAction.next,
                    hint: 'Username',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Username tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 18.0),
                  CustomTextfield(
                    controller: passwordController,
                    textInputType: TextInputType.visiblePassword,
                    textInputAction: TextInputAction.done,
                    hint: 'Password',
                    isObscure: isObscure,
                    hasSuffix: true,
                    onPressed: () {
                      setState(() {
                        isObscure = !isObscure;
                      });
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Password tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 24.0),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.gray,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                    ),
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        // Handle Sign Up logic here jika form valid
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10.0),
                      child: Text(
                        'Sign Up',
                        style: TextStyles.title.copyWith(
                          fontSize: 20.0,
                          color: AppColors.pink,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 50.0),
                  Text(
                    'Already have an account?',
                    style: TextStyles.body.copyWith(
                      fontSize: 16.0,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context); // Kembali ke LoginScreen
                    },
                    child: Text(
                      'Login',
                      style: TextStyles.body.copyWith(
                        fontSize: 16.0,
                        color: AppColors.darkBlue,
                        decoration: TextDecoration.underline,
                        decorationColor: AppColors.darkBlue,
                        decorationThickness: 2.0,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
