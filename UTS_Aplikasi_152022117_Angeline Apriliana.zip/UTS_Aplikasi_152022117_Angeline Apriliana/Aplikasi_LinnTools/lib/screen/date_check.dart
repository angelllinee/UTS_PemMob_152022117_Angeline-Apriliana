import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Untuk format tanggal

class DateCheck extends StatefulWidget {
  @override
  _DateCheckState createState() => _DateCheckState();
}

class _DateCheckState extends State<DateCheck> {
  DateTime? dateOfBirth;
  DateTime? today = DateTime.now();
  String age = '';
  String nextBirthday = '';
  String summary = '';

  // Fungsi untuk memilih tanggal
  Future<void> selectDate(BuildContext context, bool isDateOfBirth) async {
    DateTime initialDate = DateTime.now();
    if (isDateOfBirth && dateOfBirth != null) {
      initialDate = dateOfBirth!;
    }

    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );

    if (pickedDate != null) {
      setState(() {
        if (isDateOfBirth) {
          dateOfBirth = pickedDate;
        }
      });
      calculateDetails();
    }
  }

  // Fungsi untuk menghitung usia, tanggal ulang tahun berikutnya, dan ringkasan
  void calculateDetails() {
    if (dateOfBirth != null && today != null) {
      final Duration ageDuration = today!.difference(dateOfBirth!);

      final int years = (ageDuration.inDays / 365).floor();
      final int months = ((ageDuration.inDays % 365) / 30).floor();
      final int weeks = (ageDuration.inDays / 7).floor();
      final int days = ageDuration.inDays;
      final int hours = ageDuration.inHours % 24;
      final int minutes = ageDuration.inMinutes % 60;

      // Tanggal ulang tahun berikutnya
      DateTime nextBirthdayDate = DateTime(today!.year, dateOfBirth!.month, dateOfBirth!.day);
      if (nextBirthdayDate.isBefore(today!)) {
        nextBirthdayDate = DateTime(today!.year + 1, dateOfBirth!.month, dateOfBirth!.day); // Jika ulang tahun sudah lewat tahun ini
      }

      final Duration nextBirthdayDuration = nextBirthdayDate.difference(today!);
      final int monthsUntilNextBirthday = (nextBirthdayDuration.inDays / 30).floor();
      final int daysUntilNextBirthday = nextBirthdayDuration.inDays % 30;

      setState(() {
        age = '$years years, $months months';
        nextBirthday = '$monthsUntilNextBirthday months, $daysUntilNextBirthday days';
        summary = 'Summary: \n$years Years, $months Months, $weeks Weeks\n$days Days, $hours Hours, $minutes Minutes';
      });
    }
  }

  // Fungsi untuk menampilkan tanggal dalam format yang lebih mudah dibaca
  String formatDate(DateTime? date) {
    if (date != null) {
      return DateFormat('yyyy-MM-dd').format(date); // Format tanggal yang lebih sederhana
    }
    return 'No date selected';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Date and Age Calculator',
          style: TextStyle(
            fontFamily: 'Pop',
            fontSize: 22,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.pink,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white), // Menetapkan warna tombol back
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center, // Rata tengah untuk seluruh kolom
          children: [
            const SizedBox(height: 20),
            Text(
              'Select Date of Birth',
              style: TextStyle(fontFamily: 'Pop', fontSize: 20, color: Colors.black),
            ),
            // Tombol Select Date of Birth tanpa border
            ElevatedButton(
              onPressed: () => selectDate(context, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0), // Radius pada tombol
                ),
                padding: const EdgeInsets.symmetric(vertical: 15.0),
              ),
              child: Text(
                'Select Date of Birth: ${formatDate(dateOfBirth)}',
                style: const TextStyle(fontFamily: 'Pop', fontSize: 18, color: Colors.white),
              ),
            ),
            const SizedBox(height: 20),

            // Tombol Select Today tanpa border
            ElevatedButton(
              onPressed: () => selectDate(context, false),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0), // Radius pada tombol
                ),
                padding: const EdgeInsets.symmetric(vertical: 15.0),
              ),
              child: Text(
                'Select Today: ${formatDate(today)}',
                style: const TextStyle(fontFamily: 'Pop', fontSize: 18, color: Colors.white),
              ),
            ),
            const SizedBox(height: 20),

            // Tampilkan hasil usia dan ulang tahun berikutnya
            if (age.isNotEmpty || nextBirthday.isNotEmpty)
              Column(
                children: [
                  // Kolom untuk Age dengan border yang seragam
                  Container(
                    padding: const EdgeInsets.all(12.0),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.pink, width: 2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    alignment: Alignment.center, // Menyelaraskan teks ke tengah
                    child: Text(
                      'Age: $age',
                      style: const TextStyle(fontFamily: 'Pop', fontSize: 18, color: Colors.black),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Kolom untuk Next Birthday dengan border yang seragam
                  Container(
                    padding: const EdgeInsets.all(12.0),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.pink, width: 2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    alignment: Alignment.center, // Menyelaraskan teks ke tengah
                    child: Text(
                      'Next Birthday: $nextBirthday',
                      style: const TextStyle(fontFamily: 'Pop', fontSize: 18, color: Colors.black),
                    ),
                  ),
                ],
              ),
            const SizedBox(height: 40),

            // Menampilkan Summary dengan border yang seragam
            if (summary.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.pink, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center, // Menyelaraskan teks ke tengah
                child: Text(
                  summary,
                  style: const TextStyle(fontFamily: 'Pop', fontSize: 18, color: Colors.black),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
