import 'package:flutter/material.dart';

class TemperatureConverter extends StatefulWidget {
  @override
  _TemperatureConverterState createState() => _TemperatureConverterState();
}

class _TemperatureConverterState extends State<TemperatureConverter> {
  final TextEditingController _inputController = TextEditingController();
  String _fromUnit = 'Celsius';
  String _toUnit = 'Fahrenheit';
  double? _convertedValue;

  // Daftar satuan suhu
  final List<String> _units = ['Celsius', 'Fahrenheit', 'Kelvin', 'Rankine', 'Réaumur'];

  // Fungsi untuk konversi suhu
  double? convertTemperature(double value, String from, String to) {
    if (from == to) return value;

    double celsiusValue;
    // Konversi semua ke Celsius terlebih dahulu
    switch (from) {
      case 'Celsius':
        celsiusValue = value;
        break;
      case 'Fahrenheit':
        celsiusValue = (value - 32) * 5 / 9;
        break;
      case 'Kelvin':
        celsiusValue = value - 273.15;
        break;
      case 'Rankine':
        celsiusValue = (value - 491.67) * 5 / 9;
        break;
      case 'Réaumur':
        celsiusValue = value * 5 / 4;
        break;
      default:
        return null;
    }

    // Konversi dari Celsius ke satuan target
    switch (to) {
      case 'Celsius':
        return celsiusValue;
      case 'Fahrenheit':
        return celsiusValue * 9 / 5 + 32;
      case 'Kelvin':
        return celsiusValue + 273.15;
      case 'Rankine':
        return (celsiusValue + 273.15) * 9 / 5;
      case 'Réaumur':
        return celsiusValue * 4 / 5;
      default:
        return null;
    }
  }

  void _updateConversion() {
    final double? inputValue = double.tryParse(_inputController.text);
    if (inputValue != null) {
      setState(() {
        _convertedValue = convertTemperature(inputValue, _fromUnit, _toUnit);
      });
    } else {
      setState(() {
        _convertedValue = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Mengubah latar belakang menjadi putih
      appBar: AppBar(
        title: const Text(
          'Temperature',
          style: TextStyle(
            fontFamily: 'Pop',
            color: Colors.white,
            fontSize: 24, // Menyesuaikan ukuran font
          ),
        ),
        centerTitle: true, // Menambahkan tulisan di tengah
        backgroundColor: Colors.pink, // Mengubah warna header menjadi pink
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white), // Tombol back berwarna putih
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Drop-down untuk unit input
                DropdownButton<String>(
                  value: _fromUnit,
                  dropdownColor: Colors.white,
                  style: const TextStyle(
                    color: Colors.pink,
                    fontFamily: 'Pop',
                    fontSize: 20, // Ukuran font lebih besar
                  ),
                  onChanged: (String? newValue) {
                    setState(() {
                      _fromUnit = newValue!;
                      _updateConversion();
                    });
                  },
                  items: _units.map<DropdownMenuItem<String>>((String unit) {
                    return DropdownMenuItem<String>(
                      value: unit,
                      child: Text(
                        unit,
                        style: TextStyle(
                          fontFamily: 'Pop',
                          fontSize: 20, // Ukuran font lebih besar
                        ),
                      ),
                    );
                  }).toList(),
                ),
                // Input suhu
                SizedBox(
                  width: 100,
                  child: TextField(
                    controller: _inputController,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(color: Colors.black, fontFamily: 'Pop'),
                    decoration: const InputDecoration(
                      hintText: 'Enter value',
                      hintStyle: TextStyle(color: Colors.grey),
                    ),
                    onChanged: (value) => _updateConversion(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Drop-down untuk unit output
                DropdownButton<String>(
                  value: _toUnit,
                  dropdownColor: Colors.white,
                  style: const TextStyle(
                    color: Colors.pink,
                    fontFamily: 'Pop',
                    fontSize: 20, // Ukuran font lebih besar
                  ),
                  onChanged: (String? newValue) {
                    setState(() {
                      _toUnit = newValue!;
                      _updateConversion();
                    });
                  },
                  items: _units.map<DropdownMenuItem<String>>((String unit) {
                    return DropdownMenuItem<String>(
                      value: unit,
                      child: Text(
                        unit,
                        style: TextStyle(
                          fontFamily: 'Pop',
                          fontSize: 20, // Ukuran font lebih besar
                        ),
                      ),
                    );
                  }).toList(),
                ),
                // Hasil konversi
                Text(
                  _convertedValue != null
                      ? _convertedValue!.toStringAsFixed(2)
                      : '',
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 24,
                    fontFamily: 'Pop',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Divider(color: Colors.grey),
            const Text(
              'Select unit',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 16,
                fontFamily: 'Pop',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
